<?php


abstract class BaseComentarios extends BaseObject  implements Persistent {


	
	const DATABASE_NAME = 'propel';

	
	protected static $peer;


	
	protected $id;


	
	protected $livro_id = 0;


	
	protected $nome = 'null';


	
	protected $email = 'null';


	
	protected $site;


	
	protected $texto;


	
	protected $created_at;


	
	protected $updated_at;

	
	protected $aLivros;

	
	protected $alreadyInSave = false;

	
	protected $alreadyInValidation = false;

	
	public function getId()
	{

		return $this->id;
	}

	
	public function getLivroId()
	{

		return $this->livro_id;
	}

	
	public function getNome()
	{

		return $this->nome;
	}

	
	public function getEmail()
	{

		return $this->email;
	}

	
	public function getSite()
	{

		return $this->site;
	}

	
	public function getTexto()
	{

		return $this->texto;
	}

	
	public function getCreatedAt($format = 'Y-m-d H:i:s')
	{

		if ($this->created_at === null || $this->created_at === '') {
			return null;
		} elseif (!is_int($this->created_at)) {
						$ts = strtotime($this->created_at);
			if ($ts === -1 || $ts === false) { 				throw new PropelException("Unable to parse value of [created_at] as date/time value: " . var_export($this->created_at, true));
			}
		} else {
			$ts = $this->created_at;
		}
		if ($format === null) {
			return $ts;
		} elseif (strpos($format, '%') !== false) {
			return strftime($format, $ts);
		} else {
			return date($format, $ts);
		}
	}

	
	public function getUpdatedAt($format = 'Y-m-d H:i:s')
	{

		if ($this->updated_at === null || $this->updated_at === '') {
			return null;
		} elseif (!is_int($this->updated_at)) {
						$ts = strtotime($this->updated_at);
			if ($ts === -1 || $ts === false) { 				throw new PropelException("Unable to parse value of [updated_at] as date/time value: " . var_export($this->updated_at, true));
			}
		} else {
			$ts = $this->updated_at;
		}
		if ($format === null) {
			return $ts;
		} elseif (strpos($format, '%') !== false) {
			return strftime($format, $ts);
		} else {
			return date($format, $ts);
		}
	}

	
	public function setId($v)
	{

		if ($this->id !== $v) {
			$this->id = $v;
			$this->modifiedColumns[] = ComentariosPeer::ID;
		}

	} 
	
	public function setLivroId($v)
	{

		if ($this->livro_id !== $v || $v === 0) {
			$this->livro_id = $v;
			$this->modifiedColumns[] = ComentariosPeer::LIVRO_ID;
		}

		if ($this->aLivros !== null && $this->aLivros->getId() !== $v) {
			$this->aLivros = null;
		}

	} 
	
	public function setNome($v)
	{

		if ($this->nome !== $v || $v === 'null') {
			$this->nome = $v;
			$this->modifiedColumns[] = ComentariosPeer::NOME;
		}

	} 
	
	public function setEmail($v)
	{

		if ($this->email !== $v || $v === 'null') {
			$this->email = $v;
			$this->modifiedColumns[] = ComentariosPeer::EMAIL;
		}

	} 
	
	public function setSite($v)
	{

		if ($this->site !== $v) {
			$this->site = $v;
			$this->modifiedColumns[] = ComentariosPeer::SITE;
		}

	} 
	
	public function setTexto($v)
	{

		if ($this->texto !== $v) {
			$this->texto = $v;
			$this->modifiedColumns[] = ComentariosPeer::TEXTO;
		}

	} 
	
	public function setCreatedAt($v)
	{

		if ($v !== null && !is_int($v)) {
			$ts = strtotime($v);
			if ($ts === -1 || $ts === false) { 				throw new PropelException("Unable to parse date/time value for [created_at] from input: " . var_export($v, true));
			}
		} else {
			$ts = $v;
		}
		if ($this->created_at !== $ts) {
			$this->created_at = $ts;
			$this->modifiedColumns[] = ComentariosPeer::CREATED_AT;
		}

	} 
	
	public function setUpdatedAt($v)
	{

		if ($v !== null && !is_int($v)) {
			$ts = strtotime($v);
			if ($ts === -1 || $ts === false) { 				throw new PropelException("Unable to parse date/time value for [updated_at] from input: " . var_export($v, true));
			}
		} else {
			$ts = $v;
		}
		if ($this->updated_at !== $ts) {
			$this->updated_at = $ts;
			$this->modifiedColumns[] = ComentariosPeer::UPDATED_AT;
		}

	} 
	
	public function hydrate(ResultSet $rs, $startcol = 1)
	{
		try {

			$this->id = $rs->getInt($startcol + 0);

			$this->livro_id = $rs->getInt($startcol + 1);

			$this->nome = $rs->getString($startcol + 2);

			$this->email = $rs->getString($startcol + 3);

			$this->site = $rs->getString($startcol + 4);

			$this->texto = $rs->getString($startcol + 5);

			$this->created_at = $rs->getTimestamp($startcol + 6, null);

			$this->updated_at = $rs->getTimestamp($startcol + 7, null);

			$this->resetModified();

			$this->setNew(false);

						return $startcol + 8; 
		} catch (Exception $e) {
			throw new PropelException("Error populating Comentarios object", $e);
		}
	}

	
	public function delete($con = null)
	{
		if ($this->isDeleted()) {
			throw new PropelException("This object has already been deleted.");
		}

		if ($con === null) {
			$con = Propel::getConnection(ComentariosPeer::DATABASE_NAME);
		}

		try {
			$con->begin();
			ComentariosPeer::doDelete($this, $con);
			$this->setDeleted(true);
			$con->commit();
		} catch (PropelException $e) {
			$con->rollback();
			throw $e;
		}
	}

	
	public function save($con = null)
	{
    if ($this->isNew() && !$this->isColumnModified(ComentariosPeer::CREATED_AT))
    {
      $this->setCreatedAt(time());
    }

    if ($this->isModified() && !$this->isColumnModified(ComentariosPeer::UPDATED_AT))
    {
      $this->setUpdatedAt(time());
    }

		if ($this->isDeleted()) {
			throw new PropelException("You cannot save an object that has been deleted.");
		}

		if ($con === null) {
			$con = Propel::getConnection(ComentariosPeer::DATABASE_NAME);
		}

		try {
			$con->begin();
			$affectedRows = $this->doSave($con);
			$con->commit();
			return $affectedRows;
		} catch (PropelException $e) {
			$con->rollback();
			throw $e;
		}
	}

	
	protected function doSave($con)
	{
		$affectedRows = 0; 		if (!$this->alreadyInSave) {
			$this->alreadyInSave = true;


												
			if ($this->aLivros !== null) {
				if ($this->aLivros->isModified()) {
					$affectedRows += $this->aLivros->save($con);
				}
				$this->setLivros($this->aLivros);
			}


						if ($this->isModified()) {
				if ($this->isNew()) {
					$pk = ComentariosPeer::doInsert($this, $con);
					$affectedRows += 1; 										 										 
					$this->setId($pk);  
					$this->setNew(false);
				} else {
					$affectedRows += ComentariosPeer::doUpdate($this, $con);
				}
				$this->resetModified(); 			}

			$this->alreadyInSave = false;
		}
		return $affectedRows;
	} 
	
	protected $validationFailures = array();

	
	public function getValidationFailures()
	{
		return $this->validationFailures;
	}

	
	public function validate($columns = null)
	{
		$res = $this->doValidate($columns);
		if ($res === true) {
			$this->validationFailures = array();
			return true;
		} else {
			$this->validationFailures = $res;
			return false;
		}
	}

	
	protected function doValidate($columns = null)
	{
		if (!$this->alreadyInValidation) {
			$this->alreadyInValidation = true;
			$retval = null;

			$failureMap = array();


												
			if ($this->aLivros !== null) {
				if (!$this->aLivros->validate($columns)) {
					$failureMap = array_merge($failureMap, $this->aLivros->getValidationFailures());
				}
			}


			if (($retval = ComentariosPeer::doValidate($this, $columns)) !== true) {
				$failureMap = array_merge($failureMap, $retval);
			}



			$this->alreadyInValidation = false;
		}

		return (!empty($failureMap) ? $failureMap : true);
	}

	
	public function getByName($name, $type = BasePeer::TYPE_PHPNAME)
	{
		$pos = ComentariosPeer::translateFieldName($name, $type, BasePeer::TYPE_NUM);
		return $this->getByPosition($pos);
	}

	
	public function getByPosition($pos)
	{
		switch($pos) {
			case 0:
				return $this->getId();
				break;
			case 1:
				return $this->getLivroId();
				break;
			case 2:
				return $this->getNome();
				break;
			case 3:
				return $this->getEmail();
				break;
			case 4:
				return $this->getSite();
				break;
			case 5:
				return $this->getTexto();
				break;
			case 6:
				return $this->getCreatedAt();
				break;
			case 7:
				return $this->getUpdatedAt();
				break;
			default:
				return null;
				break;
		} 	}

	
	public function toArray($keyType = BasePeer::TYPE_PHPNAME)
	{
		$keys = ComentariosPeer::getFieldNames($keyType);
		$result = array(
			$keys[0] => $this->getId(),
			$keys[1] => $this->getLivroId(),
			$keys[2] => $this->getNome(),
			$keys[3] => $this->getEmail(),
			$keys[4] => $this->getSite(),
			$keys[5] => $this->getTexto(),
			$keys[6] => $this->getCreatedAt(),
			$keys[7] => $this->getUpdatedAt(),
		);
		return $result;
	}

	
	public function setByName($name, $value, $type = BasePeer::TYPE_PHPNAME)
	{
		$pos = ComentariosPeer::translateFieldName($name, $type, BasePeer::TYPE_NUM);
		return $this->setByPosition($pos, $value);
	}

	
	public function setByPosition($pos, $value)
	{
		switch($pos) {
			case 0:
				$this->setId($value);
				break;
			case 1:
				$this->setLivroId($value);
				break;
			case 2:
				$this->setNome($value);
				break;
			case 3:
				$this->setEmail($value);
				break;
			case 4:
				$this->setSite($value);
				break;
			case 5:
				$this->setTexto($value);
				break;
			case 6:
				$this->setCreatedAt($value);
				break;
			case 7:
				$this->setUpdatedAt($value);
				break;
		} 	}

	
	public function fromArray($arr, $keyType = BasePeer::TYPE_PHPNAME)
	{
		$keys = ComentariosPeer::getFieldNames($keyType);

		if (array_key_exists($keys[0], $arr)) $this->setId($arr[$keys[0]]);
		if (array_key_exists($keys[1], $arr)) $this->setLivroId($arr[$keys[1]]);
		if (array_key_exists($keys[2], $arr)) $this->setNome($arr[$keys[2]]);
		if (array_key_exists($keys[3], $arr)) $this->setEmail($arr[$keys[3]]);
		if (array_key_exists($keys[4], $arr)) $this->setSite($arr[$keys[4]]);
		if (array_key_exists($keys[5], $arr)) $this->setTexto($arr[$keys[5]]);
		if (array_key_exists($keys[6], $arr)) $this->setCreatedAt($arr[$keys[6]]);
		if (array_key_exists($keys[7], $arr)) $this->setUpdatedAt($arr[$keys[7]]);
	}

	
	public function buildCriteria()
	{
		$criteria = new Criteria(ComentariosPeer::DATABASE_NAME);

		if ($this->isColumnModified(ComentariosPeer::ID)) $criteria->add(ComentariosPeer::ID, $this->id);
		if ($this->isColumnModified(ComentariosPeer::LIVRO_ID)) $criteria->add(ComentariosPeer::LIVRO_ID, $this->livro_id);
		if ($this->isColumnModified(ComentariosPeer::NOME)) $criteria->add(ComentariosPeer::NOME, $this->nome);
		if ($this->isColumnModified(ComentariosPeer::EMAIL)) $criteria->add(ComentariosPeer::EMAIL, $this->email);
		if ($this->isColumnModified(ComentariosPeer::SITE)) $criteria->add(ComentariosPeer::SITE, $this->site);
		if ($this->isColumnModified(ComentariosPeer::TEXTO)) $criteria->add(ComentariosPeer::TEXTO, $this->texto);
		if ($this->isColumnModified(ComentariosPeer::CREATED_AT)) $criteria->add(ComentariosPeer::CREATED_AT, $this->created_at);
		if ($this->isColumnModified(ComentariosPeer::UPDATED_AT)) $criteria->add(ComentariosPeer::UPDATED_AT, $this->updated_at);

		return $criteria;
	}

	
	public function buildPkeyCriteria()
	{
		$criteria = new Criteria(ComentariosPeer::DATABASE_NAME);

		$criteria->add(ComentariosPeer::ID, $this->id);

		return $criteria;
	}

	
	public function getPrimaryKey()
	{
		return $this->getId();
	}

	
	public function setPrimaryKey($key)
	{
		$this->setId($key);
	}

	
	public function copyInto($copyObj, $deepCopy = false)
	{

		$copyObj->setLivroId($this->livro_id);

		$copyObj->setNome($this->nome);

		$copyObj->setEmail($this->email);

		$copyObj->setSite($this->site);

		$copyObj->setTexto($this->texto);

		$copyObj->setCreatedAt($this->created_at);

		$copyObj->setUpdatedAt($this->updated_at);


		$copyObj->setNew(true);

		$copyObj->setId(NULL); 
	}

	
	public function copy($deepCopy = false)
	{
				$clazz = get_class($this);
		$copyObj = new $clazz();
		$this->copyInto($copyObj, $deepCopy);
		return $copyObj;
	}

	
	public function getPeer()
	{
		if (self::$peer === null) {
			self::$peer = new ComentariosPeer();
		}
		return self::$peer;
	}

	
	public function setLivros($v)
	{


		if ($v === null) {
			$this->setLivroId('null');
		} else {
			$this->setLivroId($v->getId());
		}


		$this->aLivros = $v;
	}


	
	public function getLivros($con = null)
	{
				include_once 'lib/model/om/BaseLivrosPeer.php';

		if ($this->aLivros === null && ($this->livro_id !== null)) {

			$this->aLivros = LivrosPeer::retrieveByPK($this->livro_id, $con);

			
		}
		return $this->aLivros;
	}

} 