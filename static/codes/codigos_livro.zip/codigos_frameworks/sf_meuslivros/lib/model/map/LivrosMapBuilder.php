<?php


	
class LivrosMapBuilder {

	
	const CLASS_NAME = 'lib.model.map.LivrosMapBuilder';	

    
    private $dbMap;

	
    public function isBuilt()
    {
        return ($this->dbMap !== null);
    }

	
    public function getDatabaseMap()
    {
        return $this->dbMap;
    }

    
    public function doBuild()
    {
		$this->dbMap = Propel::getDatabaseMap('propel');
		
		$tMap = $this->dbMap->addTable('livros');
		$tMap->setPhpName('Livros');

		$tMap->setUseIdGenerator(true);

		$tMap->addPrimaryKey('ID', 'Id', 'int', CreoleTypes::INTEGER, true, null);

		$tMap->addForeignKey('COLECAO_ID', 'ColecaoId', 'int', CreoleTypes::INTEGER, 'colecaos', 'ID', true, null);

		$tMap->addColumn('NOME', 'Nome', 'string', CreoleTypes::VARCHAR, true, 100);

		$tMap->addColumn('CAPA', 'Capa', 'string', CreoleTypes::VARCHAR, false, 100);

		$tMap->addColumn('GENERO', 'Genero', 'string', CreoleTypes::VARCHAR, false, 100);

		$tMap->addColumn('AUTOR', 'Autor', 'string', CreoleTypes::VARCHAR, true, 100);

		$tMap->addColumn('EDITORA', 'Editora', 'string', CreoleTypes::VARCHAR, false, 100);

		$tMap->addColumn('ANO_PUBLIC', 'AnoPublic', 'int', CreoleTypes::DATE, false);

		$tMap->addColumn('CREATED_AT', 'CreatedAt', 'int', CreoleTypes::TIMESTAMP, false);

		$tMap->addColumn('UPDATED_AT', 'UpdatedAt', 'int', CreoleTypes::TIMESTAMP, false);
				
    } 
} 